$(document.ready(function() {
    $('tr:even').css('background-color','#F00');
   
});    