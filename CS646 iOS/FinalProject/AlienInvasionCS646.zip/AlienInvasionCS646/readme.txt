Paul Truong Nguyen
CS646
RedID: 810922821

Alien Invasion

Alien invaders fly across the screen to outmaneuver the space ship fighter. The space ship fighter attempts to defend by shooting at the alien invaders. The user taps the screen to where they want to shoot. 

Sprites are used from http://opengameart.org as well as Apple’s SpriteKit.